import json
import urllib.request
import os

def lambda_handler(event, context):
    """
    Lambda function to forward SNS notifications to Discord webhook.
    """
    webhook_url = os.environ.get('DISCORD_WEBHOOK_URL')

    if not webhook_url:
        print("ERROR: DISCORD_WEBHOOK_URL not set")
        return {'statusCode': 500, 'body': 'Webhook URL not configured'}

    # Parse SNS message
    try:
        sns_message = event['Records'][0]['Sns']
        subject = sns_message.get('Subject', 'CloudWatch Alarm')
        message_str = sns_message.get('Message', '{}')

        # Try to parse as JSON (CloudWatch alarm format)
        try:
            alarm_data = json.loads(message_str)
            alarm_name = alarm_data.get('AlarmName', 'Unknown')
            new_state = alarm_data.get('NewStateValue', 'Unknown')
            reason = alarm_data.get('NewStateReason', 'No reason provided')
            description = alarm_data.get('AlarmDescription', '')
            timestamp = alarm_data.get('StateChangeTime', '')

            # Set color based on state
            if new_state == 'ALARM':
                color = 0xFF0000  # Red
                emoji = "🚨"
            elif new_state == 'OK':
                color = 0x00FF00  # Green
                emoji = "✅"
            else:
                color = 0xFFFF00  # Yellow
                emoji = "⚠️"

            # Build Discord embed
            embed = {
                "title": f"{emoji} {alarm_name}",
                "description": description,
                "color": color,
                "fields": [
                    {"name": "상태", "value": new_state, "inline": True},
                    {"name": "시간", "value": timestamp[:19] if timestamp else "N/A", "inline": True},
                    {"name": "상세 정보", "value": reason[:1000] if reason else "N/A", "inline": False}
                ],
                "footer": {"text": "AWS CloudWatch Alarm"}
            }

            payload = {"embeds": [embed]}

        except json.JSONDecodeError:
            # Plain text message
            payload = {
                "content": f"**{subject}**\n{message_str}"
            }

    except Exception as e:
        print(f"Error parsing message: {e}")
        payload = {"content": f"CloudWatch Alert: {str(event)}"}

    # Send to Discord
    try:
        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={'Content-Type': 'application/json'}
        )

        with urllib.request.urlopen(req, timeout=10) as response:
            print(f"Discord response: {response.status}")
            return {'statusCode': 200, 'body': 'Message sent to Discord'}

    except Exception as e:
        print(f"Error sending to Discord: {e}")
        return {'statusCode': 500, 'body': str(e)}
